import React, { useState } from "react";

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  const sendMessage = async () => {
    if (!input.trim()) return;

    // Add user's message to chat
    const newMessages = [...messages, { sender: "user", text: input }];
    setMessages(newMessages);

    // Split input safely
    const parts = input.split(",");
    if (parts.length < 5) {
      setMessages([
        ...newMessages,
        { sender: "bot", text: "Please provide all 5 details: Name,LoanAmount,Salary,CreditScore,PreApprovedLimit" }
      ]);
      setInput("");
      return;
    }

    const [name, amount, salary, credit_score, pre_approved_limit] = parts;

    try {
      const response = await fetch("http://127.0.0.1:8000/master-agent/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: name.trim(),
          amount: parseFloat(amount),
          salary: parseFloat(salary),
          pre_approved_limit: parseFloat(pre_approved_limit),
          credit_score: parseInt(credit_score),
          phone: "9876543210",
          address: "Hyderabad"
        }),
      });

      if (!response.ok) throw new Error("Network response was not ok");

      const data = await response.json();
      const botMessages = data.conversation_flow.map(msg => ({
        sender: "bot",
        text: msg
      }));

      setMessages([...newMessages, ...botMessages]);
    } catch (error) {
      setMessages([
        ...newMessages,
        { sender: "bot", text: "Error connecting to server: " + error.message }
      ]);
    }

    setInput("");
  };

  return (
    <div style={{ maxWidth: 600, margin: "auto", marginTop: 50 }}>
      <h2 style={{ textAlign: "center" }}>💬 BFSI AI Chatbot</h2>
      <div style={{
        border: "1px solid #ccc",
        borderRadius: 10,
        padding: 20,
        height: 400,
        overflowY: "auto",
        background: "#f9f9f9"
      }}>
        {messages.map((msg, i) => (
          <div key={i} style={{
            textAlign: msg.sender === "user" ? "right" : "left",
            margin: "8px 0"
          }}>
            <span style={{
              display: "inline-block",
              padding: "10px 15px",
              borderRadius: "20px",
              background: msg.sender === "user" ? "#007bff" : "#eee",
              color: msg.sender === "user" ? "white" : "black"
            }}>
              {msg.text}
            </span>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", marginTop: 10 }}>
        <input
          type="text"
          placeholder="Type your message..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          style={{ flex: 1, padding: 10 }}
        />
        <button onClick={sendMessage} style={{
          background: "#007bff",
          color: "white",
          border: "none",
          padding: "10px 20px",
          marginLeft: 5,
          borderRadius: 5
        }}>
          Send
        </button>
      </div>
    </div>
  );
}

export default App;
