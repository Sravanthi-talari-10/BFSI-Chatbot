from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allows your React app to connect
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
# ---------------------------------------------
# 1️⃣ Input Model
# ---------------------------------------------
class CustomerInfo(BaseModel):
    name: str
    amount: float
    salary: float
    pre_approved_limit: float
    credit_score: int
    phone: str
    address: str


# ---------------------------------------------
# 2️⃣ Worker Agents
# ---------------------------------------------
def sales_agent(data: CustomerInfo):
    return f"Hi {data.name}! You’re interested in a loan of ₹{data.amount}. Let’s check your eligibility."

def verification_agent(data: CustomerInfo):
    # dummy check
    return f"Verified phone ({data.phone}) and address ({data.address}). ✅"

def underwriting_agent(data: CustomerInfo):
    if data.credit_score < 700:
        return {"status": "rejected", "reason": "Low credit score"}

    if data.amount <= data.pre_approved_limit:
        return {"status": "approved", "mode": "Instant approval"}

    elif data.amount <= 2 * data.pre_approved_limit:
        emi = data.amount / 12  # dummy EMI calc
        if emi <= 0.5 * data.salary:
            return {"status": "approved", "mode": "Salary verified"}
        else:
            return {"status": "rejected", "reason": "High EMI vs Salary"}

    else:
        return {"status": "rejected", "reason": "Amount exceeds allowed limit"}

def sanction_letter_agent(data: CustomerInfo, decision: dict):
    if decision["status"] == "approved":
        letter = f"""
        SANCTION LETTER
        -----------------------------
        Name: {data.name}
        Loan Amount: ₹{data.amount}
        Credit Score: {data.credit_score}
        Status: APPROVED ({decision['mode']})
        Congratulations! 🎉
        """
    else:
        letter = f"""
        SANCTION LETTER
        -----------------------------
        Name: {data.name}
        Loan Amount: ₹{data.amount}
        Status: REJECTED
        Reason: {decision['reason']}
        """
    return letter.strip()


# ---------------------------------------------
# 3️⃣ Master Agent (Main Orchestrator)
# ---------------------------------------------
@app.post("/master-agent/")
def master_agent(data: dict):
    name = data["name"]
    amount = data["amount"]
    salary = data["salary"]
    pre_approved = data["pre_approved_limit"]
    credit_score = data["credit_score"]

    conversation = []
    conversation.append(f"Hello {name}! Let's check your loan eligibility.")

    # Sales Agent
    conversation.append(f"You requested a loan of ₹{amount}.")

    # Verification Agent (simulated)
    conversation.append("Verifying KYC details... Done!")

    # Underwriting Agent
    if credit_score < 700:
        conversation.append("Sorry, your credit score is too low. Loan Rejected.")
    elif amount <= pre_approved:
        conversation.append(f"Loan Approved! Amount: ₹{amount}")
    elif amount <= 2 * pre_approved:
        emi = amount / 12  # simple EMI calculation
        if emi <= 0.5 * salary:
            conversation.append(f"Loan Approved after salary verification! EMI: ₹{emi:.2f}")
        else:
            conversation.append("EMI too high compared to your salary. Loan Rejected.")
    else:
        conversation.append("Loan amount too high. Loan Rejected.")

    # Sanction Letter Generator (simulated)
    if "Approved" in conversation[-1]:
      conversation.append("Generating Sanction Letter... Done!")
      conversation.append("🎉 Loan Approved!")
      conversation.append("Your sanction letter has been generated successfully.")
      conversation.append("Thank you for using the BFSI AI Chatbot. Have a great day!")

    return {"conversation_flow": conversation}




